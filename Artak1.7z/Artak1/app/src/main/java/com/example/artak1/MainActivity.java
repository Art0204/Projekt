package com.example.artak1;

import android.app.Activity;

public class MainActivity extends Activity {
}
