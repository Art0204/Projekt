package com.example.artak1
import android.app.Application

class App:Application() {
    override fun onCreate() {
        super.onCreate()
    }
}